<?php

class Parser extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->process();
	}

	public function process()
	{
		$sFilePath = FCPATH.'/assets/xxx-docs-yyy/RssNAV.xml';
		
		$oXML = simplexml_load_file($sFilePath);

		foreach ($oXML->channel->item as $oItem) {

			echo strval($oItem->title);

			

			print_r($oItem->title);
			die();
		}

	}

}