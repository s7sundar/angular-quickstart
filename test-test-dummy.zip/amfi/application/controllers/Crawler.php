<?php

class Crawler extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('crawler_model', 'crawler');
		$this->load->library('zip');
	}

	public function index()
	{

		if (!$this->input->is_cli_request()) {
			show_error('Direct access is not allowed');
		}

		/*echo '<a href="http://portal.amfiindia.com/RssNAV.aspx?mf=53" download>Download Now</a>';*/

		/*$sContent = file_get_contents('http://portal.amfiindia.com/RssNAV.aspx?mf=53');

		$sFilePath = FCPATH.'/assets/xxx-docs-yyy/16-02-2016.xml';

		file_put_contents($sFilePath, $sContent);*/
	}

	public function process()
	{
		$this->zip->clear_data();
		$funds = $this->crawler->get_mutual_funds();

		$timezone = new DateTimeZone("Asia/Kolkata" );
		$date = new DateTime();
		$date->setTimezone($timezone );
		log_message('error', 'Debug Message ---> CRON Time '.$date->format( 'H:i:s A  /  D, M jS, Y' ));		

		//$file_path = FCPATH.'/assets/static/'.date('Y-m-d');
		//if(!is_dir($file_path))
			//mkdir($file_path);

		$status = false;

		foreach ($funds as $fund) {
			$nav_file_name = 'nav_'.$fund->fund_id.'.xml';
			$aum_file_name = 'aum_'.$fund->fund_id.'.xml';
			//$nav_file = $file_path.'/nav_'.$fund->fund_id.'.xml';
			//$aum_file = $file_path.'/aum_'.$fund->fund_id.'.xml';
			$bStatus = false;

			if(!empty($fund->nav_link)) {				
				//$fund->nav_link = 'http://localhost/amfi/assets/nav.xml';
				$nav_content = $this->get_data($fund->nav_link);
				$this->zip->add_data($nav_file_name, $nav_content);				
				//file_put_contents($nav_file, $nav_content);
				$status = true;
			}

			if(!empty($fund->aum_link)) {
				//$fund->aum_link = 'http://localhost/amfi/assets/aum.xml';
				$aum_content = $this->get_data($fund->aum_link);
				$this->zip->add_data($aum_file_name, $aum_content);				
				//file_put_contents($aum_file, $aum_content);
				$status = true;
			}			
		}

		if($status)
			$this->zip_static_files();

	}

	private function get_data($url)
	{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HEADER, false);
		$data = curl_exec($curl);
		curl_close($curl);
		return $data;
	}

	private function zip_static_files()
	{		
		$zip_file_name = date('Y-m-d').'.zip';
		$zip_file_path = FCPATH.'/assets/static/'.$zip_file_name;
		$this->zip->archive($zip_file_path);
	}
}