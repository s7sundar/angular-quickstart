<?php

class Crawler_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function get_mutual_funds()
	{
		$result = $this->db->get('amfii_india_funds');
		return $result->result();
	}
}