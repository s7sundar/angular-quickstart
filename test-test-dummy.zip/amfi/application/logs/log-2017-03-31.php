<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-03-31 06:13:44 --> Debug Message ---> CRON Time 11:43:44 AM  /  Fri, Mar 31st, 2017
ERROR - 2017-03-31 09:03:38 --> Debug Message ---> CRON Time 14:33:38 PM  /  Fri, Mar 31st, 2017
