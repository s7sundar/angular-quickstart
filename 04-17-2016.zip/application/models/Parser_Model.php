<?php

class Parser_Model extends CI_Model
{

	public function get_mutual_funds()
	{
		return $this->db->get('amfii_india_funds')->result();
	}

	public function process($fund_id, $xml)
	{
		foreach ($xml->channel->item as $fund) {
			$this->update_fund_details($fund_id,$fund);
		}
	}

	private function update_fund_details($fund_id, $fund)
	{
		$desc_params = array();
		$fund_name = strval($fund->title);
		$fund_link = strval($fund->link);
		$urlparams = parse_url($fund_link);
		parse_str($urlparams['query'], $url);
		$dparams = $this->get_description_params($fund);
		$params = array();
		$params['fund_id'] = $fund_id;
		$params['parent_id'] = $url['cmbmfname'];
		$params['fund_details_id'] = $url['SdId'];		
		$chk = $this->db->get_where('fund_name_details', $params);
		if($chk->num_rows() == 0) {			
			$params['fund_name'] = $fund_name;
			$params['fund_link'] = $fund_link;
			$params['category'] = $dparams['Category'];
			$this->db->insert('fund_name_details', $params);
			$fund_name_id = $this->db->insert_id();
		}
		else {
			$row = $chk->row();
			$fund_name_id = $row->fund_name_id;
		}
		$this->update_nav_details($fund_name_id, $dparams);
	}

	private function update_nav_details($fund_name_id, $params)
	{
		$insert = array();
		$insert['fund_name_id'] = $fund_name_id;
		$insert['nav'] = trim($params['NAV']);
		$insert['repurchase_price'] = trim($params['Repurchase Price']);
		$insert['sale_price'] = trim($params['Sale Price']);
		$date = trim($params['Date']);
		$insert['mdate'] = date('Y-m-d', strtotime($date));
		$this->db->insert('fund_nav_details', $insert);
	}

	private function get_description_params($fund) {
		$params  = array();
		$cdata = strval($fund->description);
		$cdata = $this->stripAttributes($cdata);
		$xml  = simplexml_load_string($cdata);
		$tr = $xml->body->table->tr;
		for($i=0; $i<count($tr); $i++) {
			$item = $tr[$i];
			$key = strval($item->td->b);			
			$value = strval($item->td[1]);
			$key = trim($key);	
			$params[$key] = $value;
		}
		return $params;
	}

	private function stripAttributes($html) {
	   	$domd = new DOMDocument();
		libxml_use_internal_errors(true);
		$domd->loadHTML($html);
		libxml_use_internal_errors(false);

		$domx = new DOMXPath($domd);
		$items = $domx->query("//td[@style]");

		foreach($items as $item) {
		  $item->removeAttribute("style");
		}
		return $domd->saveHTML();
	}



	//=================================== Update new funds 
	public function load_new_funds($xml)
	{
		foreach ($xml->option as $fund_name) {
			$parent_id = strval($fund_name->attributes()['value']);			
			$fund_id = $this->verify_uniquness($fund_name);
			if($fund_id > 0) {
				$update = array('parent_id'=>$parent_id);
				$where = array('fund_id'=>$fund_id);
				$this->db->update('amfii_india_funds',$update, $where);				
			}
			else {
				$insert = array();
				$insert['parent_id'] = $parent_id;
				$insert['fund_name'] = $fund_name;
				$this->db->insert('amfii_india_funds', $insert);
			}
		}

	}

	private function verify_uniquness($fund_name) 
	{
		$chk  = $this->db->get_where('amfii_india_funds', array(
			'fund_name'=>$fund_name
		));

		if($chk->num_rows() > 0) {
			$result = $chk->row_array();
			return $result['fund_id'];
		}

		return 0;
	}
}