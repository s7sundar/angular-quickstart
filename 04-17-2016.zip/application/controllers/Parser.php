<?php

class Parser extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Parser_Model', 'parser');
	}

	public function index()
	{
		$this->process();
	}

	public function process()
	{
		$funds = $this->parser->get_mutual_funds();
		foreach($funds as $fund) {
			$file_path = FCPATH.'/assets/static/'.date('Y-m-d');
			$file_path .= '/nav_'.$fund->fund_id.'.xml';
			if(is_file($file_path) && is_readable($file_path)) {				
				$xml = simplexml_load_file($file_path);
				$this->parser->process($fund->fund_id, $xml);
			}
		}
	}

	public function load_new_funds()
	{
		$xml_file = FCPATH.'/assets/static/mf-list.xml';
		$xml = simplexml_load_file($xml_file);
		$this->parser->load_new_funds($xml);
	}

}